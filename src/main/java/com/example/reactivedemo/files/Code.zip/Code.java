//package com.example.reactivedemo.files;

public class Code{
    public static void main(String[] args) {
        System.out.println("Lambda function hello world");
    }
}